import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-icons/iron-icons.js';

class HelloElement extends PolymerElement{
    static get template() {
        return html`
        <form name='myform'>
        <table>
        <tr>
        <td>
       ID</td><td> <input value="{{id::input}}"/></td></tr>
        <tr>
        <td>
        Name</td><td><input value="{{name::input}}"/></td></tr>
        <tr>
        <td>
        Salary</td><td><input value="{{salary::input}}"/></td></tr>
        <tr>
        <td>
        Department</td><td><input value="{{dept::input}}"/></td></tr>
        
      
        </table>
        </form>
        <button on-click="printDetail">Add Employee</button>
        
    
        <br>
        <h2>[[id]] [[name]] [[salary]] [[dept]]</h2>
        `}
        static get properties(){
            return {
                name:String,
                salary:Number,
                dept:String,
                id:Number,
                
            };
            
        }
        
           printDetail(){
               alert(this.id+" "+this.name+" "+this.salary+" "+this.dept);
           }
        
        
}
customElements.define('hello-element', HelloElement);